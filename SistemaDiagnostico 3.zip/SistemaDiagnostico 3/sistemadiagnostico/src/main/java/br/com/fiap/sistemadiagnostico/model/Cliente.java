package br.com.fiap.sistemadiagnostico.model;

public class Cliente {
    private String idCliente;
    private String nome;
    private String sobrenome;
    private String endereco;
    private String telefone;
    private Veiculo veiculo;  // Relacionamento com Veiculo

    public Cliente(String idCliente, String nome, String sobrenome, String endereco, String telefone) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    // Getters
    public String getIdCliente() {
        return idCliente;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    // Setters
    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }
}
