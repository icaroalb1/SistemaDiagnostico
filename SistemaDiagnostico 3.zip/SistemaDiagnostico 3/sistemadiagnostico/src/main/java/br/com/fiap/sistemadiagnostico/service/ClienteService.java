package br.com.fiap.sistemadiagnostico.service;

import br.com.fiap.sistemadiagnostico.dao.ClienteDAO;
import br.com.fiap.sistemadiagnostico.model.Cliente;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {
    private ClienteDAO clienteDAO = new ClienteDAO();

    // Método para validar e inserir cliente com retorno de mensagem de sucesso/falha
    public String inserirCliente(Cliente cliente) throws Exception {
        validarCliente(cliente); // Valida os dados do cliente
        boolean success = clienteDAO.inserirCliente(cliente); // Chama o método de inserção do DAO
        if (success) {
            return "Cliente inserido com sucesso.";
        } else {
            return "Falha ao inserir cliente.";
        }
    }

    // Método para validar e ler cliente
    public Cliente lerCliente(String idCliente) throws Exception {
        if (idCliente == null || idCliente.isEmpty()) {
            throw new Exception("ID do cliente inválido.");
        }
        return clienteDAO.lerCliente(idCliente);
    }

    // Método para validar e atualizar cliente
    public void atualizarCliente(Cliente cliente) throws Exception {
        validarCliente(cliente);
        clienteDAO.atualizarCliente(cliente);
    }

    // Método para validar e deletar cliente
    public void deletarCliente(String idCliente) throws Exception {
        if (idCliente == null || idCliente.isEmpty()) {
            throw new Exception("ID do cliente inválido.");
        }
        clienteDAO.deletarCliente(idCliente);
    }

    // Método de validação para dados do cliente
    private void validarCliente(Cliente cliente) throws Exception {
        if (cliente.getNome() == null || cliente.getNome().isEmpty()) {
            throw new Exception("Nome do cliente é obrigatório.");
        }
        if (cliente.getSobrenome() == null || cliente.getSobrenome().isEmpty()) {
            throw new Exception("Sobrenome do cliente é obrigatório.");
        }
        if (cliente.getEndereco() == null || cliente.getEndereco().isEmpty()) {
            throw new Exception("Endereço do cliente é obrigatório.");
        }
        if (cliente.getTelefone() == null || cliente.getTelefone().isEmpty()) {
            throw new Exception("Telefone do cliente é obrigatório.");
        }
    }
}
