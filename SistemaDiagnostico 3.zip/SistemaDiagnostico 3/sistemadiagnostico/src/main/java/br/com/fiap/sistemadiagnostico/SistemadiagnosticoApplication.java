package br.com.fiap.sistemadiagnostico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemadiagnosticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemadiagnosticoApplication.class, args);
	}

}
