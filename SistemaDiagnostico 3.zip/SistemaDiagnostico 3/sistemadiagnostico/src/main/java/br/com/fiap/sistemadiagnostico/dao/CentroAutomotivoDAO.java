package br.com.fiap.sistemadiagnostico.dao;

import br.com.fiap.sistemadiagnostico.model.CentroAutomotivo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CentroAutomotivoDAO {

    public boolean insert(CentroAutomotivo centro) {
        String sql = "INSERT INTO centro_automotivo (nome, endereco, telefone) VALUES (?, ?, ?)";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, centro.getNome());
            stmt.setString(2, centro.getEndereco());
            stmt.setString(3, centro.getTelefone());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }

    public List<CentroAutomotivo> getAll() {
        List<CentroAutomotivo> centros = new ArrayList<>();
        String sql = "SELECT * FROM centro_automotivo";
        Connection conn = ConexaoDB.conectar();
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                CentroAutomotivo centro = new CentroAutomotivo(rs.getInt("id"), rs.getString("nome"), rs.getString("endereco"), rs.getString("telefone"));
                centros.add(centro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConexaoDB.desconectar(conn);
        }
        return centros;
    }

    public boolean update(CentroAutomotivo centro) {
        String sql = "UPDATE centro_automotivo SET nome = ?, endereco = ?, telefone = ? WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, centro.getNome());
            stmt.setString(2, centro.getEndereco());
            stmt.setString(3, centro.getTelefone());
            stmt.setInt(4, centro.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM centro_automotivo WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }
}
