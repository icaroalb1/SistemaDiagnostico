package br.com.fiap.sistemadiagnostico.resource;

import br.com.fiap.sistemadiagnostico.model.Servico;
import br.com.fiap.sistemadiagnostico.service.ServicosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping("/servicos")
public class ServicosController {

    @Autowired
    private ServicosService servicosService;

    private static final Logger LOGGER = Logger.getLogger(ServicosController.class.getName());

    @PostMapping
    public ResponseEntity<String> createServico(@RequestBody Servico servico) {
        try {
            boolean success = servicosService.insert(servico);
            if (success) {
                return new ResponseEntity<>("Serviço criado com sucesso.", HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>("Falha ao criar serviço.", HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao criar serviço", e);
            return new ResponseEntity<>("Erro ao criar serviço: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    public ResponseEntity<?> getAllServicos() {
        try {
            return ResponseEntity.ok(servicosService.getAll());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao buscar serviços", e);
            return new ResponseEntity<>("Erro ao buscar serviços: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateServico(@PathVariable int id, @RequestBody Servico servico) {
        try {
            servico.setId(id);
            boolean success = servicosService.update(servico);
            if (success) {
                return ResponseEntity.ok("Serviço atualizado com sucesso.");
            } else {
                return new ResponseEntity<>("Serviço não encontrado.", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao atualizar serviço", e);
            return new ResponseEntity<>("Erro ao atualizar serviço: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteServico(@PathVariable int id) {
        try {
            boolean success = servicosService.delete(id);
            if (success) {
                return ResponseEntity.ok("Serviço deletado com sucesso.");
            } else {
                return new ResponseEntity<>("Serviço não encontrado.", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao deletar serviço", e);
            return new ResponseEntity<>("Erro ao deletar serviço: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
