package br.com.fiap.sistemadiagnostico.model;

public class Funcionario {
    private int idFuncionario;
    private String nome;
    private String cargo;
    private double salario;
    private CentroAutomotivo centroTrabalho;

    public Funcionario(int idFuncionario, String nome, String cargo, double salario, CentroAutomotivo centroTrabalho) {
        this.idFuncionario = idFuncionario;
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
        this.centroTrabalho = centroTrabalho;
    }

    // Getters e Setters
    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public CentroAutomotivo getCentroTrabalho() {
        return centroTrabalho;
    }

    public void setCentroTrabalho(CentroAutomotivo centroTrabalho) {
        this.centroTrabalho = centroTrabalho;
    }
}
