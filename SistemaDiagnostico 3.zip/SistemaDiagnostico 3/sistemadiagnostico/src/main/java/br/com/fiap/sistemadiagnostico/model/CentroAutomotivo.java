package br.com.fiap.sistemadiagnostico.model;

import java.util.ArrayList;
import java.util.List;

public class CentroAutomotivo {
    private int idCentro;
    private String nome;
    private String endereco;
    private String telefone;
    private List<Servico> servicosOferecidos;

    public CentroAutomotivo(int idCentro, String nome, String endereco, String telefone) {
        this.idCentro = idCentro;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.servicosOferecidos = new ArrayList<>(); // Inicializa a lista para evitar NullPointerException
    }

    // Método para listar os serviços oferecidos
    public void listaDeServico() {
        System.out.println("Serviços oferecidos pelo centro automotivo:");
        for (Servico servico : servicosOferecidos) {
            System.out.println("Serviço: " + servico.getDescricao() + " - Preço: R$ " + servico.getPreco());
        }
    }

    // Método para adicionar um serviço à lista
    public void adicionarServico(Servico servico) {
        servicosOferecidos.add(servico);
    }

    // Getters e Setters
    public int getIdCentro() {
        return idCentro;
    }

    public void setIdCentro(int idCentro) {
        this.idCentro = idCentro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public List<Servico> getServicosOferecidos() {
        return servicosOferecidos;
    }

    public void setServicosOferecidos(List<Servico> servicosOferecidos) {
        this.servicosOferecidos = servicosOferecidos;
    }

    public int getId() {
        return idCentro;
    }
}
