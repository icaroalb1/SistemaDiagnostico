package br.com.fiap.sistemadiagnostico.model;

import java.util.Date;

public class Pagamento {
    private int idPagamento;
    private OrdemServico ordemServico;
    private double valorTotal;
    private Date dataPagamento;
    private String metodoPagamento;
    private Cliente cliente;

    public Pagamento(int idPagamento, OrdemServico ordemServico, double valorTotal, Date dataPagamento, String metodoPagamento, Cliente cliente) {
        this.idPagamento = idPagamento;
        this.ordemServico = ordemServico;
        this.valorTotal = valorTotal;
        this.dataPagamento = dataPagamento;
        this.metodoPagamento = metodoPagamento;
        this.cliente = cliente;
    }

    public void calculoDePagamento() {
        this.valorTotal = ordemServico.getServicos().stream()
                .mapToDouble(Servico::getPreco)
                .sum();
    }

    // Getters e Setters
    public int getIdPagamento() {
        return idPagamento;
    }

    public void setIdPagamento(int idPagamento) {
        this.idPagamento = idPagamento;
    }

    public OrdemServico getOrdemServico() {
        return ordemServico;
    }

    public void setOrdemServico(OrdemServico ordemServico) {
        this.ordemServico = ordemServico;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public String getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(String metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
