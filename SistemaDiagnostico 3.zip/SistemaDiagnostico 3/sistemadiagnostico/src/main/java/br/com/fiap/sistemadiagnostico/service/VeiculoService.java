package br.com.fiap.sistemadiagnostico.service;

import br.com.fiap.sistemadiagnostico.dao.VeiculoDAO;
import br.com.fiap.sistemadiagnostico.model.Veiculo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VeiculoService {
    private VeiculoDAO veiculoDAO = new VeiculoDAO();

    // Método para validar e inserir veículo, retorna true se o veículo foi inserido com sucesso
    public boolean insert(Veiculo veiculo) throws Exception {
        validarVeiculo(veiculo); // Valida os dados do veículo
        return veiculoDAO.insert(veiculo); // Chama o método de inserção do DAO
    }

    // Método para obter todos os veículos
    public List<Veiculo> getAll() throws Exception {
        return veiculoDAO.getAll();
    }

    // Método para validar e atualizar veículo, retorna true se o veículo foi atualizado com sucesso
    public boolean update(Veiculo veiculo) throws Exception {
        validarVeiculo(veiculo); // Valida os dados do veículo

        // Verifica se o veículo existe pelo ID antes de atualizar
        Veiculo existingVeiculo = veiculoDAO.findById(veiculo.getId());
        if (existingVeiculo != null) {
            // Atualiza o veículo caso exista
            return veiculoDAO.update(veiculo);
        } else {
            // Log adicional para depuração
            System.out.println("Não foi possível encontrar o veículo com o ID: " + veiculo.getId());
            return false;
        }
    }

    // Método para validar e deletar veículo, retorna true se o veículo foi deletado com sucesso
    public boolean delete(int idVeiculo) throws Exception {
        if (idVeiculo <= 0) {
            throw new Exception("ID do veículo inválido.");
        }
        return veiculoDAO.delete(idVeiculo);
    }

    // Método de validação para dados do veículo
    private void validarVeiculo(Veiculo veiculo) throws Exception {
        if (veiculo.getMarca() == null || veiculo.getMarca().isEmpty()) {
            throw new Exception("Marca do veículo é obrigatória.");
        }
        if (veiculo.getModelo() == null || veiculo.getModelo().isEmpty()) {
            throw new Exception("Modelo do veículo é obrigatório.");
        }
        if (veiculo.getAno() <= 0) {
            throw new Exception("Ano do veículo é inválido.");
        }
        if (veiculo.getPlaca() == null || veiculo.getPlaca().isEmpty()) {
            throw new Exception("Placa do veículo é obrigatória.");
        }
    }
}
