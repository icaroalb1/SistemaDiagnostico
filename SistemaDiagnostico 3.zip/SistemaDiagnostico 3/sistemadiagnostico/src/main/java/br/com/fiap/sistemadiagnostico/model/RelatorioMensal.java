package br.com.fiap.sistemadiagnostico.model;

import java.util.List;

public class RelatorioMensal {
    private int idRelatorio;
    private int mes;
    private int ano;
    private double totalFaturado;
    private double totalDespesas;

    public RelatorioMensal(int idRelatorio, int mes, int ano, double totalFaturado, double totalDespesas) {
        this.idRelatorio = idRelatorio;
        this.mes = mes;
        this.ano = ano;
        this.totalFaturado = totalFaturado;
        this.totalDespesas = totalDespesas;
    }

    // Cálculo do faturamento
    public void calcularFaturamento(List<OrdemServico> ordens) {
        this.totalFaturado = ordens.stream()
                .flatMap(ordem -> ordem.getServicos().stream())
                .mapToDouble(Servico::getPreco)
                .sum();
    }

    // Cálculo das despesas
    public void calcularDespesas(double despesasFixas, double outrasDespesas) {
        this.totalDespesas = despesasFixas + outrasDespesas;
    }

    // Relatório detalhado com cliente, serviços e valores pagos
    public void relatorioMensalDetalhado(List<OrdemServico> ordens) {
        System.out.println("Relatório Mensal Detalhado:");
        System.out.println("Mês: " + this.mes + " Ano: " + this.ano);
        ordens.forEach(ordem -> {
            System.out.println("Ordem ID: " + ordem.getIdOrdemServico() + " Cliente: " + ordem.getCliente().getNome());
            ordem.getServicos().forEach(servico -> {
                System.out.println("Serviço: " + servico.getDescricao() + " Preço: " + servico.getPreco());
            });
            System.out.println("Total Pago pelo Cliente: R$ " + ordem.calcularValorTotalCliente());
        });
        System.out.println("----------");
        System.out.println("Total Faturado: R$ " + this.totalFaturado);
        System.out.println("Total de Despesas: R$ " + this.totalDespesas);
        System.out.println("Lucro Líquido: R$ " + (this.totalFaturado - this.totalDespesas));
        System.out.println("----------");
    }

    // Getters e Setters
    public int getIdRelatorio() {
        return idRelatorio;
    }

    public void setIdRelatorio(int idRelatorio) {
        this.idRelatorio = idRelatorio;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public double getTotalFaturado() {
        return totalFaturado;
    }

    public void setTotalFaturado(double totalFaturado) {
        this.totalFaturado = totalFaturado;
    }

    public double getTotalDespesas() {
        return totalDespesas;
    }

    public void setTotalDespesas(double totalDespesas) {
        this.totalDespesas = totalDespesas;
    }
}
