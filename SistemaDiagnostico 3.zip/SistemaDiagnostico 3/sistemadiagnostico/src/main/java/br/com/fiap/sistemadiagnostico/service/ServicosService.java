package br.com.fiap.sistemadiagnostico.service;

import br.com.fiap.sistemadiagnostico.dao.ServicoDAO;
import br.com.fiap.sistemadiagnostico.model.Servico;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicosService {

    private ServicoDAO servicoDAO = new ServicoDAO();

    // Método para validar e inserir serviço, retorna true se o serviço foi inserido com sucesso
    public boolean insert(Servico servico) throws Exception {
        validarServico(servico); // Valida os dados do serviço
        return servicoDAO.insert(servico); // Chama o método de inserção do DAO
    }

    // Método para obter todos os serviços
    public List<Servico> getAll() throws Exception {
        return servicoDAO.getAll();
    }

    // Método para validar e atualizar serviço, retorna true se o serviço foi atualizado com sucesso
    public boolean update(Servico servico) throws Exception {
        validarServico(servico); // Valida os dados do serviço
        return servicoDAO.update(servico);
    }

    // Método para validar e deletar serviço, retorna true se o serviço foi deletado com sucesso
    public boolean delete(int idServico) throws Exception {
        if (idServico <= 0) {
            throw new Exception("ID do serviço inválido.");
        }
        return servicoDAO.delete(idServico);
    }

    // Método de validação para dados do serviço
    private void validarServico(Servico servico) throws Exception {
        if (servico.getDescricao() == null || servico.getDescricao().isEmpty()) {
            throw new Exception("Descrição do serviço é obrigatória.");
        }
        if (servico.getPreco() < 0) {
            throw new Exception("Preço do serviço é inválido.");
        }
    }
}
