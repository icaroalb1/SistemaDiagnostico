package br.com.fiap.sistemadiagnostico.resource;

import br.com.fiap.sistemadiagnostico.model.Cliente;
import br.com.fiap.sistemadiagnostico.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    private static final Logger LOGGER = Logger.getLogger(ClienteController.class.getName());

    @PostMapping
    public ResponseEntity<String> inserirCliente(@RequestBody Cliente cliente) {
        try {
            String resultado = clienteService.inserirCliente(cliente); // Recebe a mensagem de sucesso/falha do ClienteService
            return new ResponseEntity<>(resultado, HttpStatus.CREATED);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao inserir cliente", e);
            return new ResponseEntity<>("Erro ao inserir cliente: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{idCliente}")
    public ResponseEntity<?> lerCliente(@PathVariable String idCliente) {
        try {
            Cliente cliente = clienteService.lerCliente(idCliente);
            return ResponseEntity.ok(cliente);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao ler cliente", e);
            return new ResponseEntity<>("Erro ao ler cliente: " + e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping
    public ResponseEntity<String> atualizarCliente(@RequestBody Cliente cliente) {
        try {
            clienteService.atualizarCliente(cliente);
            return ResponseEntity.ok("Cliente atualizado com sucesso.");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao atualizar cliente", e);
            return new ResponseEntity<>("Erro ao atualizar cliente: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{idCliente}")
    public ResponseEntity<String> deletarCliente(@PathVariable String idCliente) {
        try {
            clienteService.deletarCliente(idCliente);
            return ResponseEntity.ok("Cliente deletado com sucesso.");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao deletar cliente", e);
            return new ResponseEntity<>("Erro ao deletar cliente: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
