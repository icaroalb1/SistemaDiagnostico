package br.com.fiap.sistemadiagnostico.dao;

import br.com.fiap.sistemadiagnostico.model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {

    // Método para inserir um cliente no banco de dados com confirmação de sucesso
    public boolean inserirCliente(Cliente cliente) {
        Connection conexao = ConexaoDB.conectar();
        String sql = "INSERT INTO CLIENTE (IDCLIENTE, NOME, SOBRENOME, ENDERECO, TELEFONE) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, cliente.getIdCliente());
            stmt.setString(2, cliente.getNome());
            stmt.setString(3, cliente.getSobrenome());
            stmt.setString(4, cliente.getEndereco());
            stmt.setString(5, cliente.getTelefone());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Retorna verdadeiro se a inserção foi bem-sucedida
        } catch (SQLException e) {
            System.out.println("Erro ao inserir cliente: " + e.getMessage());
            return false; // Retorna falso se a inserção falhar
        } finally {
            ConexaoDB.desconectar(conexao);
        }
    }

    // Método para ler um cliente específico
    public Cliente lerCliente(String idCliente) {
        Connection conexao = ConexaoDB.conectar();
        String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE = ?";
        Cliente cliente = null;

        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, idCliente);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                cliente = new Cliente(
                        rs.getString("IDCLIENTE"),
                        rs.getString("NOME"),
                        rs.getString("SOBRENOME"),
                        rs.getString("ENDERECO"),
                        rs.getString("TELEFONE")
                );
            }
        } catch (SQLException e) {
            System.out.println("Erro ao ler cliente: " + e.getMessage());
        } finally {
            ConexaoDB.desconectar(conexao);
        }
        return cliente;
    }

    // Método para atualizar as informações de um cliente
    public void atualizarCliente(Cliente cliente) {
        Connection conexao = ConexaoDB.conectar();
        String sql = "UPDATE CLIENTE SET NOME = ?, SOBRENOME = ?, ENDERECO = ?, TELEFONE = ? WHERE IDCLIENTE = ?";

        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getSobrenome());
            stmt.setString(3, cliente.getEndereco());
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getIdCliente());
            stmt.executeUpdate();
            System.out.println("Cliente atualizado com sucesso.");
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar cliente: " + e.getMessage());
        } finally {
            ConexaoDB.desconectar(conexao);
        }
    }

    // Método para deletar um cliente do banco de dados
    public void deletarCliente(String idCliente) {
        Connection conexao = ConexaoDB.conectar();
        String sql = "DELETE FROM CLIENTE WHERE IDCLIENTE = ?";

        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, idCliente);
            stmt.executeUpdate();
            System.out.println("Cliente deletado com sucesso.");
        } catch (SQLException e) {
            System.out.println("Erro ao deletar cliente: " + e.getMessage());
        } finally {
            ConexaoDB.desconectar(conexao);
        }
    }
}
