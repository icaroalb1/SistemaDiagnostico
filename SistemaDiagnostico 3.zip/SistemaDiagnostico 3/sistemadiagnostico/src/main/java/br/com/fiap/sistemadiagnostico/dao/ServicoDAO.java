package br.com.fiap.sistemadiagnostico.dao;

import br.com.fiap.sistemadiagnostico.model.Servico;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServicoDAO {

    public boolean insert(Servico servico) {
        String sql = "INSERT INTO servico (descricao, preco) VALUES (?, ?)"; // Corrigido para 'preco'
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, servico.getDescricao());
            stmt.setDouble(2, servico.getPreco());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }

    public List<Servico> getAll() {
        List<Servico> servicos = new ArrayList<>();
        String sql = "SELECT * FROM servico";
        Connection conn = ConexaoDB.conectar();
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Servico servico = new Servico(rs.getInt("id"), rs.getString("descricao"), rs.getDouble("preco")); // Corrigido para 'preco'
                servicos.add(servico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConexaoDB.desconectar(conn);
        }
        return servicos;
    }

    public boolean update(Servico servico) {
        String sql = "UPDATE servico SET descricao = ?, preco = ? WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, servico.getDescricao());
            stmt.setDouble(2, servico.getPreco());
            stmt.setInt(3, servico.getIdServico());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM servico WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }
}
