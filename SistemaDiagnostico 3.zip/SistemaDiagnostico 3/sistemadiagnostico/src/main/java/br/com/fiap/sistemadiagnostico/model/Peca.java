package br.com.fiap.sistemadiagnostico.model;

public class Peca {
    private String nomePeca;
    private double precoPeca;
    private int quantidadePeca;

    public Peca(String nomePeca, double precoPeca, int quantidadePeca) {
        this.nomePeca = nomePeca;
        this.precoPeca = precoPeca;
        this.quantidadePeca = quantidadePeca;
    }

    // Método para calcular o valor total do estoque de peças
    public double calcularValorEstoque() {
        return precoPeca * quantidadePeca;
    }

    // Getters e Setters
    public String getNomePeca() {
        return nomePeca;
    }

    public void setNomePeca(String nomePeca) {
        this.nomePeca = nomePeca;
    }

    public double getPrecoPeca() {
        return precoPeca;
    }

    public void setPrecoPeca(double precoPeca) {
        this.precoPeca = precoPeca;
    }

    public int getQuantidadePeca() {
        return quantidadePeca;
    }

    public void setQuantidadePeca(int quantidadePeca) {
        this.quantidadePeca = quantidadePeca;
    }
}
