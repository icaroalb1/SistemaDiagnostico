package br.com.fiap.sistemadiagnostico.model;

import java.util.Date;
import java.util.List;

public class OrdemServico {
    private int idOrdemServico;
    private Cliente cliente;
    private Veiculo veiculo;
    private List<Servico> servicos;
    private Date dataEntrada;
    private Date dataSaida;
    private String status;

    public OrdemServico(int idOrdemServico, Cliente cliente, Veiculo veiculo, List<Servico> servicos, Date dataEntrada, Date dataSaida, String status) {
        this.idOrdemServico = idOrdemServico;
        this.cliente = cliente;
        this.veiculo = veiculo;
        this.servicos = servicos;
        this.dataEntrada = dataEntrada;
        this.dataSaida = dataSaida;
        this.status = status;
    }

    // Método para calcular o valor total dos serviços prestados ao cliente
    public double calcularValorTotalCliente() {
        return this.servicos.stream()
                .mapToDouble(Servico::getPreco)
                .sum();
    }

    // Getters e Setters
    public int getIdOrdemServico() {
        return idOrdemServico;
    }

    public void setIdOrdemServico(int idOrdemServico) {
        this.idOrdemServico = idOrdemServico;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public List<Servico> getServicos() {
        return servicos;
    }

    public void setServicos(List<Servico> servicos) {
        this.servicos = servicos;
    }

    public Date getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(Date dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public Date getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(Date dataSaida) {
        this.dataSaida = dataSaida;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
