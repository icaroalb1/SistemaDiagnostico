package br.com.fiap.sistemadiagnostico.dao;

import br.com.fiap.sistemadiagnostico.model.Veiculo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO {

    // Método para inserir um veículo e definir o ID gerado automaticamente
    public boolean insert(Veiculo veiculo) {
        String sql = "INSERT INTO veiculos (id, modelo, marca, ano_fabricacao, placa) VALUES (?, ?, ?, ?, ?)";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, veiculo.getId()); // Agora estamos passando o ID enviado pelo usuário
            stmt.setString(2, veiculo.getModelo());
            stmt.setString(3, veiculo.getMarca());
            stmt.setInt(4, veiculo.getAno());
            stmt.setString(5, veiculo.getPlaca());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }


    // Método para buscar todos os veículos
    public List<Veiculo> getAll() {
        List<Veiculo> veiculos = new ArrayList<>();
        String sql = "SELECT * FROM veiculos";
        Connection conn = ConexaoDB.conectar();
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Veiculo veiculo = new Veiculo(
                        rs.getInt("id"),
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("ano_fabricacao")
                );
                veiculos.add(veiculo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConexaoDB.desconectar(conn);
        }
        return veiculos;
    }

    // Método para buscar um veículo pelo ID
    public Veiculo findById(int id) {
        String sql = "SELECT * FROM veiculos WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Veiculo veiculo = new Veiculo(
                        rs.getInt("id"),
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("ano_fabricacao")
                );
                System.out.println("Veículo encontrado: " + veiculo); // Log para depuração
                return veiculo;
            } else {
                System.out.println("Nenhum veículo encontrado com o ID: " + id); // Log para depuração
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConexaoDB.desconectar(conn);
        }
        return null; // Retorna null se o veículo não for encontrado
    }

    // Método para atualizar um veículo existente
    public boolean update(Veiculo veiculo) {
        String sql = "UPDATE veiculos SET modelo = ?, marca = ?, ano_fabricacao = ?, placa = ? WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, veiculo.getModelo());
            stmt.setString(2, veiculo.getMarca());
            stmt.setInt(3, veiculo.getAno());
            stmt.setString(4, veiculo.getPlaca());
            stmt.setInt(5, veiculo.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }

    // Método para deletar um veículo pelo ID
    public boolean delete(int id) {
        String sql = "DELETE FROM veiculos WHERE id = ?";
        Connection conn = ConexaoDB.conectar();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexaoDB.desconectar(conn);
        }
    }
}
