package br.com.fiap.sistemadiagnostico.model;

public class Servico {
    private int idServico;
    private String descricao;
    private double preco;

    // Construtor com parâmetros
    public Servico(int idServico, String descricao, double preco) {
        this.idServico = idServico;
        this.descricao = descricao;
        this.preco = preco;
    }

    // Construtor sem parâmetros
    public Servico() {
    }

    // Getters e Setters
    public int getIdServico() {
        return idServico;
    }

    public void setIdServico(int idServico) {
        this.idServico = idServico;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setId(int id) {

    }
}
