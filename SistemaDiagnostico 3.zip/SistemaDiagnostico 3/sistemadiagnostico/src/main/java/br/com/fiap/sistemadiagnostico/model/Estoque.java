package br.com.fiap.sistemadiagnostico.model;

import java.util.Date;

public class Estoque {
    private int idEstoque;
    private int quantidadePeca;
    private Date dataEntrada;
    private Date dataSaida;
    private Fornecedor fornecedor;

    public Estoque(int idEstoque, int quantidadePeca, Date dataEntrada, Date dataSaida, Fornecedor fornecedor) {
        this.idEstoque = idEstoque;
        this.quantidadePeca = quantidadePeca;
        this.dataEntrada = dataEntrada;
        this.dataSaida = dataSaida;
        this.fornecedor = fornecedor;
    }

    // Método para calcular o estoque
    public void calcularEstoque(int entrada, int saida) {
        this.quantidadePeca += entrada;
        this.quantidadePeca -= saida;
    }

    // Getters e Setters
    public int getIdEstoque() {
        return idEstoque;
    }

    public void setIdEstoque(int idEstoque) {
        this.idEstoque = idEstoque;
    }

    public int getQuantidadePeca() {
        return quantidadePeca;
    }

    public void setQuantidadePeca(int quantidadePeca) {
        this.quantidadePeca = quantidadePeca;
    }

    public Date getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(Date dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public Date getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(Date dataSaida) {
        this.dataSaida = dataSaida;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }
}
