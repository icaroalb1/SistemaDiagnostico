package br.com.fiap.sistemadiagnostico.resource;

import br.com.fiap.sistemadiagnostico.model.Veiculo;
import br.com.fiap.sistemadiagnostico.service.VeiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping("/veiculos")
@Service
public class VeiculoController {

    @Autowired
    private VeiculoService veiculoService;

    private static final Logger LOGGER = Logger.getLogger(VeiculoController.class.getName());

    @PostMapping
    public ResponseEntity<String> createVeiculo(@RequestBody Veiculo veiculo) {
        try {
            boolean success = veiculoService.insert(veiculo);
            if (success) {
                return new ResponseEntity<>("Veículo criado com sucesso.", HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>("Falha ao criar veículo.", HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao criar veículo", e);
            return new ResponseEntity<>("Erro ao criar veículo: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    public ResponseEntity<?> getAllVeiculos() {
        try {
            return ResponseEntity.ok(veiculoService.getAll());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao buscar veículos", e);
            return new ResponseEntity<>("Erro ao buscar veículos: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateVeiculo(@PathVariable int id, @RequestBody Veiculo veiculo) {
        try {
            veiculo.setId(id);
            boolean success = veiculoService.update(veiculo);
            if (success) {
                return ResponseEntity.ok("Veículo atualizado com sucesso.");
            } else {
                return new ResponseEntity<>("Veículo não encontrado.", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao atualizar veículo", e);
            return new ResponseEntity<>("Erro ao atualizar veículo: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteVeiculo(@PathVariable int id) {
        try {
            boolean success = veiculoService.delete(id);
            if (success) {
                return ResponseEntity.ok("Veículo deletado com sucesso.");
            } else {
                return new ResponseEntity<>("Veículo não encontrado.", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro ao deletar veículo", e);
            return new ResponseEntity<>("Erro ao deletar veículo: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
