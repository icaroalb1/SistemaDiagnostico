package br.com.fiap.sistemadiagnostico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemadiagnosticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
